<?php

 $conn = mysqli_connect('localhost','root','','form1',);

 $name = $_POST['name'];
 $pass = $_POST['pass'];
 $email = $_POST['email'];
 $phone = $_POST['cell'];

 if($name && $pass && $email && $phone){
 	mysqli_query($conn, " INSERT INTO user_info (name, pass, email, phone) VALUES ('$name', '$pass','$email', '$phone')");

 header("location: index.php");
 }else{
 	echo "Please fill up the form!!!!";
 };


 








?>