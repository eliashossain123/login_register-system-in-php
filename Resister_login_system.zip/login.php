<?php

$conn = mysqli_connect('localhost','root','','form1');

$name = $_POST['username'];
$pass = $_POST['pass'];

$info = mysqli_query($conn, "SELECT * FROM user_info where name='$name' and pass='$pass' ");

$numOfRows = mysqli_num_rows($info);

if($numOfRows == 1){
	header('location: profile.php');
}else{
	header('location: error.php');
}







?>