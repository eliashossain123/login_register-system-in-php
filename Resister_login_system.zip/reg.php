<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Php login register system</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="log">
    <h2>Sign Up Here</h2>
    <hr>
    <form action="registration.php" method="POST">
        <label for="">Username</label>
        <input name="name" type="text">

        <label for="">Password</label>
        <input name="pass" type="password">

        <label for="">Email</label>
        <input name="email" type="text">

        <label for="">Phone</label>
        <input name="cell" type="text">

        <input type="submit" value="Sign Up"> 
        <hr>
        <a href="index.php">Login Now</a>
    </form>
</div>
    
</body>
</html>