<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Php login register system</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="log">
    <h2>Login Here</h2>
    <hr>
    <form action="login.php" method="POST">
        <label for="">Username</label>
        <input name="username" type="text">

        <label for="">Password</label>
        <input name="pass" type="password">

        <input type="submit" value="Login"> 
        <hr>
        <a href="reg.php">Creat an account</a>
    </form>
</div>
    
</body>
</html>